<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Visit extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model(array(
            'visit_model',
			'setting_model'
        )); 
	    $this->load->library('session');	
    }
    
	
	
    public function index()
    {   
       
	   $data['title'] = 'Visit List';
	   $data['visits'] = $this->visit_model->read();
	   $data['content'] = $this->load->view('visit_view', $data, true);
	   $this->load->view('layout/main_wrapper', $data);
        
    }  
	
	 public function view()
    {   
       
	   /*$data['title'] = 'Visit List';
	   $data['visits'] = $this->visit_model->read();
	   $data['content'] = $this->load->view('visit_view', $data, true);
	   $this->load->view('layout/main_wrapper', $data);*/
	   
	   $data['title'] = "Visit List";
		if ($this->input->post('submit') != '') {
            $data['search'] = $postData = [               
                'emp_name' => $this->input->post('emp_name'),
				'visit_comp_id' => $this->input->post('company_id')
            ];
            $this->session->set_userdata('search_visit', $data['search']);
        }
		$config["base_url"] = base_url('visit/view');
        $config["total_rows"] = $this->pagination_model->read_visit_list_count('visit_planner', $this->session->userdata('search_visit'));
        $config["per_page"] = 15;
        $config["uri_segment"] = 4;
        $config["num_links"] = 5;

        /* This Application Must Be Used With BootStrap 3 * */
        $config['next_link']        = 'Next';
		$config['prev_link']        = 'Prev';
		$config['first_link']       = false;
		$config['last_link']        = false;
		$config['full_tag_open']    = '<ul class="pagination justify-content-center">';
		$config['full_tag_close']   = '</ul>';
		$config['attributes']       = ['class' => 'page-link'];
		$config['first_tag_open']   = '<li class="page-item">';
		$config['first_tag_close']  = '</li>';
		$config['prev_tag_open']    = '<li class="page-item">';
		$config['prev_tag_close']   = '</li>';
		$config['next_tag_open']    = '<li class="page-item">';
		$config['next_tag_close']   = '</li>';
		$config['last_tag_open']    = '<li class="page-item">';
		$config['last_tag_close']   = '</li>';
		$config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
		$config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
		$config['num_tag_open']     = '<li class="page-item">';
		$config['num_tag_close']    = '</li>';
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        $data['links'] = $this->pagination->create_links();
        $data['wholesalers'] = $this->pagination_model->read_visit_list($config["per_page"], $page, $this->session->userdata('search_visit'));
        $data['content'] = $this->load->view('visit/view', $data, true);
        $this->load->view('layout/main_wrapper', $data);
		
		/*$data['members'] = $this->member_model->read();
		$data['content'] = $this->load->view('members/view',$data,true);
		$this->load->view('layout/main_wrapper',$data);*/
        
    }  
	
	public function getClients() 
    {
        $cid = $this->input->post('cid');
		$ctype = $this->input->post('ctype');
		if(!empty($cid) && $ctype == 'doctors'){ 
		$result = $this->visit_model->getDoctors($cid);
		$str = '';
		 
		if(count($result) > 0){ 
         foreach($result as $row){  
			
			$str .= '<option value="'.$row->id.'">'.$row->dr_doctor_name.'</option>'; 
        } 
		echo $str;	
     }else{ 
        echo '<option value="">No Record Found</option>'; 
      } 
     }
		if(!empty($cid) && $ctype == 'wholesaler'){ 
		$result = $this->visit_model->getWholesaler($cid);
		$str = '';
		 
		if(count($result) > 0){ 
         foreach($result as $row){  
			
			$str .= '<option value="'.$row->id.'">'.$row->wholesaler_name.'</option>'; 
        } 
		echo $str;	
     }else{ 
        echo '<option value="">No Record Found</option>'; 
      } 
     }
		if(!empty($cid) && $ctype == 'pharmacy'){ 
		$result = $this->visit_model->getPharmacy($cid);
		$str = '';
		 
		if(count($result) > 0){ 
         foreach($result as $row){  
			
			$str .= '<option value="'.$row->id.'">'.$row->pharm_pharmacy_name.'</option>'; 
        } 
		echo $str;	
     }else{ 
        echo '<option value="">No Record Found</option>'; 
      } 
     }
		
	}
	
	public function getMemebrs() 
    {
        $cid = $this->input->post('cid');
		if(!empty($cid)){ 
		$result = $this->visit_model->getMemebrs($cid);
			//print_r($result);
		$str = '';
		if(count($result) > 0){ 
         foreach($result as $row){  
			
			$str .= '<option value="'.$row->id.'">'.$row->emp_name.'</option>'; 
        } 
		echo $str;	
     }else{ 
        echo '<option value="">No Record Found</option>'; 
      } 
     }
	}	
	
	public function delete()
    {
     
		$cid = $_POST['cid'];

		$deletePassword = $_POST['deletePassword'];
		$logged_user	= $this->session->userdata('user_id');
		$row = $this->db->query("select * from users where us_id = $logged_user")->row();
		
		if( md5(trim($deletePassword)) != $row->us_password )
		{
		  echo json_encode(2);
		
		} else {
		$queryUpdate = $this->db->query("update visit_planner set visit_is_deleted =1 where visit_id = $cid");  
 		  echo json_encode($queryUpdate);	
		}
	}
    
	
	
    public function add($id = null)
    {
        
		
		$this->form_validation->set_rules('visit_company_id', 'Company', 'required');
    	
		$visit_date = trim($this->input->post('visit_date'));
		$visit_time = trim($this->input->post('timepicker-24-hr'));
		
		$datetime =$visit_date.' '.$visit_time;
		//$datetime = date ('Y-m-d H:i:s', strtotime($datetime));
		
		
		
		$data['record'] = (object)$postData = array(
			'visit_id' => $this->input->post('visit_id'),
            'visit_company_id' => $this->input->post('visit_company_id'),
			'visit_client_type' => $this->input->post('visit_client_type'),
			'visit_client_id' => $this->input->post('visit_client_id'),
			'visit_member_id' => $this->input->post('visit_member_id'),
			'visit_datetime' => $datetime,
			'visit_created_datetime' => date("Y-m-d h:i"),
			'visit_created_by' => $this->session->userdata('user_id'),
			'visit_status' => $this->input->post('visit_status')
        );
		
		$data['recordUp'] = (object)$postDataUpdate = array(
			'visit_id' => $this->input->post('visit_id'),
            'visit_company_id' => $this->input->post('visit_company_id'),
			'visit_client_type' => $this->input->post('visit_client_type'),
			'visit_client_id' => $this->input->post('visit_client_id'),
			'visit_member_id' => $this->input->post('visit_member_id'),
			'visit_datetime' => $datetime,
			'visit_updated_datetime' => date("Y-m-d h:i"),
			'visit_status' => $this->input->post('visit_status'),
			'visit_updated_by' => $this->session->userdata('user_id')
        );
		
	   
        /*-----------CHECK ID -----------*/
       
		if (empty($id)) {
			
		    /*-----------CREATE A NEW RECORD-----------*/
            if ($this->form_validation->run() === true) {
			    
			
				if ($this->visit_model->create($postData)) {
					
					#set success message
                    $this->session->set_flashdata('message', 'Added Successfully');
                } else {
				    
                    #set exception message
                    $this->session->set_flashdata('exception', display('please_try_again'));
                }
			
                redirect('visit/add');
            } else {
            
                $data['title'] = 'Add Visit';
                $data['content'] = $this->load->view('visit_form', $data, true);
				
				$this->load->view('layout/main_wrapper', $data);
            }
		} else {
		   
		   if ($this->form_validation->run() === true) { 
                if ($this->visit_model->update($postDataUpdate)) {
				  
                    #set success message
                    $this->session->set_flashdata('message', 'Updated Successfully');
                } else {
				    
                    #set exception message
                    $this->session->set_flashdata('exception', display('please_try_again'));
                }
			
               redirect('visit');
            } else {
            
                $data['title'] = 'Edit Visit';
			    $data['row'] = $this->visit_model->read_by_id($id);
                $data['content'] = $this->load->view('visit_form', $data, true);
				$this->load->view('layout/main_wrapper', $data);
            }	
			
			
		}
       
        /*---------------------------------*/
    }
    
 
}
