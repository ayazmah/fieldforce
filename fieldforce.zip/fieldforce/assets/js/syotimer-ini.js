! function() {
    "use strict";

    $(document).ready(function() {
       $('.simple_timer').syotimer({
          year: 2020,
          month: 4,
          day: 9,
          hour: 20,
          minute: 30
      })

    })
}();